<?php

namespace Mpdf\Tag;

class Font extends InlineTag
{


}
