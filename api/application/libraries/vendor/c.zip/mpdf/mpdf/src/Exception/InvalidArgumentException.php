<?php

namespace Mpdf\Exception;

class InvalidArgumentException extends \Mpdf\MpdfException
{

}
